package Doctor;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MedicalRecord extends JFrame {
    private JTextField medicineNameField, medicalTestsField;

    public MedicalRecord() {
        setTitle("Medical Record");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(224, 251, 226));

        JLabel medicineLabel = new JLabel("Medicine Name:");
        JLabel testsLabel = new JLabel("Medical Tests:");
        medicineLabel.setFont(new Font("Arial", Font.BOLD, 16));
        testsLabel.setFont(new Font("Arial", Font.BOLD, 16));
        medicineLabel.setBounds(50, 100, 150, 30);
        testsLabel.setBounds(50, 150, 150, 30);

        medicineNameField = new JTextField();
        medicalTestsField = new JTextField();
        medicineNameField.setBounds(200, 100, 200, 30);
        medicalTestsField.setBounds(200, 150, 200, 30);

        JButton backButton = new JButton("Back");
        JButton sendButton = new JButton("Send to Receptionist");
        backButton.setBounds(50, 200, 150, 40);
        sendButton.setBounds(220, 200, 200, 40);
        backButton.setBackground(new Color(7, 15, 43)); 
        sendButton.setBackground(new Color(7, 15, 43)); 
        backButton.setForeground(Color.WHITE);
        sendButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        sendButton.setFont(new Font("Arial", Font.BOLD, 14));

        JLabel welcomeLabel = new JLabel("Medical Record of Patient");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(new Color(7, 15, 43)); 
        welcomeLabel.setBounds(50, 50, 300, 30);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DoctorDashboard doctorDashboard = new DoctorDashboard();
                doctorDashboard.setVisible(true);
                setVisible(false);
            }
        });

        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                writeToMedicalRecord();
            }
        });

        add(medicineLabel);
        add(testsLabel);
        add(medicineNameField);
        add(medicalTestsField);
        add(backButton);
        add(sendButton);
        add(welcomeLabel);

        setLayout(null);
        setVisible(true);
    }

    private void writeToMedicalRecord() {
        String medicineName = medicineNameField.getText();
        String medicalTests = medicalTestsField.getText();
        try {
            FileWriter writer = new FileWriter("medical_record.txt", true);
            writer.write("Medicine Name: " + medicineName + ", Medical Tests: " + medicalTests + "\n");
            writer.close();
            JOptionPane.showMessageDialog(this, "Data saved successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while saving the data.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MedicalRecord();
            }
        });
    }
}
