package Doctor;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class DoctorNotifications extends JFrame {
    private JLabel titleLabel;
    private JTextArea notificationsArea;
    private JButton backButton;

    public DoctorNotifications() {
    
        setTitle("Doctor Notifications");
        setSize(900, 600);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        ImageIcon backgroundImage = new ImageIcon("images/rsz_medical.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, 900, 600);
        add(backgroundLabel);
        
        titleLabel = new JLabel("Your Notifications");
        titleLabel.setForeground(new Color(7, 15, 43)); 
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBounds(50, 50, 300, 30);
        backgroundLabel.add(titleLabel);
        
        notificationsArea = new JTextArea();
        notificationsArea.setEditable(false);
        notificationsArea.setFont(new Font("Calibri", Font.PLAIN, 16));
        notificationsArea.setBackground(Color.WHITE);
        notificationsArea.setBounds(50, 100, 800, 400);
        backgroundLabel.add(notificationsArea);

        loadNotifications();

        backButton = new JButton("Back");
        backButton.setForeground(new Color(255, 255, 255));
        backButton.setBackground(new Color(7, 15, 43)); 
        backButton.setFocusPainted(false);
        backButton.setBounds(400, 520, 100, 30);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DoctorDashboard doctorDashboard = new DoctorDashboard();
                doctorDashboard.setVisible(true);
                setVisible(false);
            }
        });
        backgroundLabel.add(backButton);
        setVisible(true);
    }

    private void loadNotifications() {
        try (BufferedReader reader = new BufferedReader(new FileReader("notification.txt"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            notificationsArea.setText(sb.toString());
        } catch (IOException e) {
            e.printStackTrace();
            notificationsArea.setText("Error loading notifications.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DoctorNotifications::new);
    }
}
