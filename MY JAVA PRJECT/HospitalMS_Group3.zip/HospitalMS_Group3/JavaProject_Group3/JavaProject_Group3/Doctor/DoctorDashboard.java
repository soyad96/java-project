package Doctor;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DoctorDashboard extends JFrame implements ActionListener {

    private JButton viewAppointmentsBtn, prescribeBtn, sendRecordsBtn, showNotificationBtn;

    
    public DoctorDashboard() {
    
        setTitle("Doctor Dashboard");
        setSize(900, 600);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        ImageIcon backgroundImage = new ImageIcon("images/rsz_medical.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, 900, 600);
        add(backgroundLabel);
        
        JLabel messageLabel = new JLabel("Wherever the art of medicine is loved, there is also a love for humanity.");
        messageLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
        messageLabel.setForeground(Color.DARK_GRAY);
        
        int messageLabelWidth = 800; 
        int messageLabelX = (getWidth() - messageLabelWidth) / 2;
        messageLabel.setBounds(messageLabelX, 20, messageLabelWidth, 30);
        backgroundLabel.add(messageLabel);
        
        Font buttonFont = new Font("Arial", Font.BOLD, 18);
        
        viewAppointmentsBtn = new JButton("View Patient Appointments");
        viewAppointmentsBtn.setFont(buttonFont);
        int buttonWidth = 300;
        int buttonX = (getWidth() - buttonWidth) / 2;
        viewAppointmentsBtn.setBounds(buttonX, 100, buttonWidth, 50);
        viewAppointmentsBtn.addActionListener(this);
        backgroundLabel.add(viewAppointmentsBtn);
        
        prescribeBtn = new JButton("Prescribe");
        prescribeBtn.setFont(buttonFont);
        prescribeBtn.setBounds(buttonX, 200, buttonWidth, 50);
        prescribeBtn.addActionListener(this);
        backgroundLabel.add(prescribeBtn);
        
        sendRecordsBtn = new JButton("Send Records to Receptionist");
        sendRecordsBtn.setFont(buttonFont);
        sendRecordsBtn.setBounds(buttonX, 300, buttonWidth, 50);
        sendRecordsBtn.addActionListener(this);
        backgroundLabel.add(sendRecordsBtn);
        
        showNotificationBtn = new JButton("Show Notification");
        showNotificationBtn.setFont(buttonFont);
        showNotificationBtn.setBounds(buttonX, 400, buttonWidth, 50);
        showNotificationBtn.addActionListener(this);
        backgroundLabel.add(showNotificationBtn);
        

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == viewAppointmentsBtn) {
            ViewAppointment viewAppointment = new ViewAppointment();
            viewAppointment.setVisible(true);
            setVisible(false);
        } else if (e.getSource() == prescribeBtn) {
            Prescription prescription = new Prescription();
            prescription.setVisible(true);
            setVisible(false);
        } else if (e.getSource() == sendRecordsBtn) {
            MedicalRecord medicalRecord = new MedicalRecord();
            medicalRecord.setVisible(true);
            setVisible(false);
        } else if (e.getSource() == showNotificationBtn) {
            DoctorNotifications doctorNotifications = new DoctorNotifications();
            doctorNotifications.setVisible(true);
            setVisible(false);
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DoctorDashboard();
        });
    }
}
