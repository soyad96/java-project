package Admin;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminDashboard extends JFrame implements ActionListener {

    private JButton userManagementButton, sendNotificationsButton;

    public AdminDashboard() {
        
        setTitle("Admin Dashboard");
        setSize(600, 500);
        setResizable(false);
        getContentPane().setBackground(Color.decode("#EEF5FF"));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        userManagementButton = createButton("User Management");
        sendNotificationsButton = createButton("Send Notifications");
        
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10); 
        add(userManagementButton, gbc);

        gbc.gridy++;
        add(sendNotificationsButton, gbc);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(button.getFont().deriveFont(Font.BOLD));
        button.setForeground(Color.WHITE);
        button.setBackground(Color.decode("#070F2B"));
        button.setPreferredSize(new Dimension(200, 50));
        button.addActionListener(this);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == userManagementButton) {
            UserManagement userManagement = new UserManagement();
            userManagement.setVisible(true);
            setVisible(false);
        } else if (e.getSource() == sendNotificationsButton) {
            Notification notification = new Notification();
            notification.setVisible(true);
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AdminDashboard dashboard = new AdminDashboard();
            dashboard.setVisible(true);
        });
    }
}
