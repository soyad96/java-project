package Admin;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.io.*;
import java.nio.file.*;

public class UserManagement extends JFrame {

    private Container c;
    //private ImageIcon icon;
    private JLabel label1;
    private Font f1, f2, f3;
    private JScrollPane scroll;
    private JTable table;
    private DefaultTableModel model;
    private JButton btn1, btn2, btn3, btn4, btn5, nBtn;
    private Cursor cursor;

    private String[] column = {"User Name", "Password", "Role"};

    public UserManagement() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Admin Dashboard");
        this.setSize(700, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.decode("#F2F2F2"));

        f1 = new Font("Segoe UI Black", Font.BOLD, 40);
        f2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        f3 = new Font("Segoe UI", Font.PLAIN, 20);

        cursor = new Cursor(Cursor.HAND_CURSOR);

        label1 = new JLabel();
        label1.setText("User Management");
        label1.setBounds(150, 10, 400, 80);
        label1.setFont(f1);
        c.add(label1);

        btn1 = new JButton("Refresh");
        btn1.setBounds(54, 418, 184, 50);
        btn1.setFont(f2);
        btn1.setCursor(cursor);
        btn1.setForeground(Color.WHITE);
        btn1.setBackground(Color.decode("#2E75B6"));
        c.add(btn1);

        btn2 = new JButton("Delete");
        btn2.setBounds(248, 418, 184, 50);
        btn2.setFont(f2);
        btn2.setCursor(cursor);
        btn2.setForeground(Color.WHITE);
        btn2.setBackground(Color.decode("#2E75B6"));
        c.add(btn2);

        btn3 = new JButton("Add");
        btn3.setBounds(442, 418, 184, 50);
        btn3.setFont(f2);
        btn3.setCursor(cursor);
        btn3.setForeground(Color.WHITE);
        btn3.setBackground(Color.decode("#2E75B6"));
        c.add(btn3);

        btn4 = new JButton("Update");
        btn4.setBounds(54, 480, 278, 50);
        btn4.setFont(f2);
        btn4.setCursor(cursor);
        btn4.setForeground(Color.WHITE);
        btn4.setBackground(Color.decode("#2E75B6"));
        c.add(btn4);

        btn5 = new JButton("Back");
        btn5.setBounds(342, 480, 284, 50);
        btn5.setFont(f2);
        btn5.setCursor(cursor);
        btn5.setForeground(Color.WHITE);
        btn5.setBackground(Color.decode("#2E75B6"));
        c.add(btn5);

        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);

        table = new JTable();
        model = new DefaultTableModel();
        model.setColumnIdentifiers(column);

        table.setModel(model);
        table.setFont(f3);
        table.setSelectionBackground(Color.decode("#8AC5FF"));
        table.setBackground(Color.WHITE);
        table.setRowHeight(30);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getColumnModel().getColumn(0).setPreferredWidth(120);
        table.getColumnModel().getColumn(1).setPreferredWidth(140);
        table.getColumnModel().getColumn(2).setPreferredWidth(160);

        scroll = new JScrollPane(table);
        scroll.setBounds(110, 96, 419, 300);
        scroll.setBackground(Color.WHITE);
        scroll.setPreferredSize(new Dimension(578, 300));
        c.add(scroll);

        String userDataFile = "C:\\Users\\kkaif\\Downloads\\JavaProject_Group3\\JavaProject_Group3\\data\\data.txt";
        try {
            BufferedReader reader = new BufferedReader(new FileReader(userDataFile));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split("\\s+");
                model.addRow(userData);
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                AdminDashboard frame = new AdminDashboard();
                frame.setVisible(true);
            }
        });


        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                int[] selectedRows = table.getSelectedRows();
                for (int i = selectedRows.length - 1; i >= 0; i--) {
                    int modelRow = table.convertRowIndexToModel(selectedRows[i]); 
                    model.removeRow(modelRow); 
                    try {
                        
                        Path filePath = Paths.get(userDataFile);
                        java.util.List<String> lines = Files.readAllLines(filePath);
                        lines.remove(modelRow);
                        Files.write(filePath, lines);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JTextField usernameField = new JTextField();
                JTextField passwordField = new JTextField();
                JTextField roleField = new JTextField();
        
                JPanel panel = new JPanel(new GridLayout(0, 1));
                panel.add(new JLabel("Username:"));
                panel.add(usernameField);
                panel.add(new JLabel("Password:"));
                panel.add(passwordField);
                panel.add(new JLabel("Role"));
                panel.add(roleField);
        
                int result = JOptionPane.showConfirmDialog(null, panel, "Add New User",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (result == JOptionPane.OK_OPTION) {
                    String username = usernameField.getText();
                    String password = passwordField.getText();
                    String role = roleField.getText();
        
                
                    String[] userData = {username, password, role};
                    model.addRow(userData);
        
                    
                    try {
                        BufferedWriter writer = new BufferedWriter(new FileWriter(userDataFile, true));
                        writer.write(username + "\t " + password + "\t   " + role);
                        writer.newLine();
                        writer.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        
        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to update.");
                    return;
                }

                String currentUsername = (String) model.getValueAt(selectedRow, 0);
                String currentPassword = (String) model.getValueAt(selectedRow, 1);
                String currentRole = (String) model.getValueAt(selectedRow, 2);

                JTextField usernameField = new JTextField(currentUsername);
                JTextField passwordField = new JTextField(currentPassword);
                JTextField roleField = new JTextField(currentRole);

                JPanel panel = new JPanel(new GridLayout(0, 1));
                panel.add(new JLabel("Username:"));
                panel.add(usernameField);
                panel.add(new JLabel("Password:"));
                panel.add(passwordField);
                panel.add(new JLabel("Role:"));
                panel.add(roleField);

                int result = JOptionPane.showConfirmDialog(null, panel, "Update User",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (result == JOptionPane.OK_OPTION) {
                    String newUsername = usernameField.getText();
                    String newPassword = passwordField.getText();
                    String newRole = roleField.getText();

                    model.setValueAt(newUsername, selectedRow, 0);
                    model.setValueAt(newPassword, selectedRow, 1);
                    model.setValueAt(newRole, selectedRow, 2);

                    try (BufferedReader reader = new BufferedReader(new FileReader(userDataFile))) {
                        java.util.List<String> lines = new java.util.ArrayList<>();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            lines.add(line);
                        }
                        lines.set(selectedRow, newUsername + "\t " + newPassword + "\t   " + newRole);
                        Files.write(Paths.get(userDataFile), lines);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        btn5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                AdminDashboard adminDashboard = new AdminDashboard();
                adminDashboard.setVisible(true);
                setVisible(false);
            }
        });
    }

    public static void main(String[] args) {
        UserManagement userManagement = new UserManagement();
        userManagement.setVisible(true);
    }
}
