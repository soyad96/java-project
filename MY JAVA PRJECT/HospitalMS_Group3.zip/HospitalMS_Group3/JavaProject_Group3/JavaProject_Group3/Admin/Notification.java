package Admin;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Notification extends JFrame implements ActionListener {
    private JTextField notificationField, dateTimeField;
    private JButton backButton, sendButton;
    private JLabel welcomeLabel, notificationLabel, dateTimeLabel;

    public Notification() {
        setTitle("Send Notification");
        setSize(600, 300); 
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(238, 245, 255)); 

        welcomeLabel = new JLabel("Welcome", SwingConstants.CENTER);
        welcomeLabel.setFont(welcomeLabel.getFont().deriveFont(Font.BOLD));
        welcomeLabel.setForeground(new Color(7, 15, 43));
        welcomeLabel.setPreferredSize(new Dimension(550, 30));

        notificationLabel = new JLabel("Write the Notification");
        notificationLabel.setFont(notificationLabel.getFont().deriveFont(Font.BOLD));
        notificationLabel.setForeground(new Color(7, 15, 43)); 
        notificationField = new JTextField(20);
        notificationField.setPreferredSize(new Dimension(500, 60)); 

        dateTimeLabel = new JLabel("Time and Date");
        dateTimeLabel.setFont(dateTimeLabel.getFont().deriveFont(Font.BOLD));
        dateTimeLabel.setForeground(new Color(7, 15, 43)); 
        dateTimeField = new JTextField(20);
        dateTimeField.setPreferredSize(new Dimension(500, 30)); 


        backButton = new JButton("Back");
        sendButton = new JButton("Send");
        backButton.setFont(backButton.getFont().deriveFont(Font.BOLD));
        sendButton.setFont(sendButton.getFont().deriveFont(Font.BOLD));
        backButton.setForeground(Color.WHITE);
        sendButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(7, 15, 43)); 
        sendButton.setBackground(new Color(7, 15, 43)); 
        backButton.setPreferredSize(new Dimension(120, 40));
        sendButton.setPreferredSize(new Dimension(120, 40));
        backButton.addActionListener(this);
        sendButton.addActionListener(this);

        JPanel textFieldPanel = new JPanel();
        textFieldPanel.setLayout(new BoxLayout(textFieldPanel, BoxLayout.Y_AXIS));
        textFieldPanel.add(notificationLabel);
        textFieldPanel.add(notificationField);
        textFieldPanel.add(dateTimeLabel);
        textFieldPanel.add(dateTimeField);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(welcomeLabel, BorderLayout.NORTH);
        getContentPane().add(textFieldPanel, BorderLayout.CENTER);


        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); 
        buttonPanel.add(backButton);
        buttonPanel.add(sendButton);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH); 
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            AdminDashboard adminDashboard = new AdminDashboard();
            adminDashboard.setVisible(true);
            setVisible(false);
        } else if (e.getSource() == sendButton) {
        
            String notificationText = notificationField.getText();
            String dateTimeText = dateTimeField.getText();
            if (!notificationText.isEmpty() && !dateTimeText.isEmpty()) {
                
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("notification.txt", true))) {
                    writer.write("Notification: " + notificationText + ", Date & Time: " + dateTimeText);
                    writer.newLine();
                    writer.flush();
                    JOptionPane.showMessageDialog(this, "Notification successfully sent!");
                    dispose(); 
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Failed to send notification. Please try again later.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please enter both notification text and date & time.");
            }
        }
    }

    public static void main(String[] args) {
        Notification notification = new Notification();
        notification.setVisible(true);
    }
}
