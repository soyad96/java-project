package Receptionist;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ReceptionistDashboard extends JFrame implements ActionListener {
    public ReceptionistDashboard() {
        setTitle("Receptionist Dashboard");
        setSize(750, 550);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container container = getContentPane();
        container.setBackground(new Color(230, 255, 148)); 
        container.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 

    
        JLabel welcomeLabel = new JLabel("Hello and Welcome");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(new Color(17, 66, 50)); 
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        container.add(welcomeLabel, gbc);

        JButton medicalRecordButton = new JButton("Medical Record View");
        medicalRecordButton.setFont(new Font("Arial", Font.BOLD, 16));
        medicalRecordButton.setForeground(Color.WHITE); 
        medicalRecordButton.setBackground(new Color(17, 66, 50)); 
        medicalRecordButton.addActionListener(this);
        medicalRecordButton.setActionCommand("medicalRecord");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        container.add(medicalRecordButton, gbc);

        JButton generateBillButton = new JButton("Generate Patient Bill");
        generateBillButton.setFont(new Font("Arial", Font.BOLD, 16));
        generateBillButton.setForeground(Color.WHITE); 
        generateBillButton.setBackground(new Color(17, 66, 50)); 
        generateBillButton.addActionListener(this);
        generateBillButton.setActionCommand("generateBill");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        container.add(generateBillButton, gbc);

        JButton showNotificationsButton = new JButton("Show Notifications");
        showNotificationsButton.setFont(new Font("Arial", Font.BOLD, 16));
        showNotificationsButton.setForeground(Color.WHITE); 
        showNotificationsButton.setBackground(new Color(17, 66, 50));
        showNotificationsButton.addActionListener(this);
        showNotificationsButton.setActionCommand("showNotifications");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        container.add(showNotificationsButton, gbc);
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("medicalRecord")) {
            MedicalView medicalView = new MedicalView();
            medicalView.setVisible(true);
            setVisible(false);
        } else if (command.equals("generateBill")) {
            GenerateBill generateBill = new GenerateBill();
            generateBill.setVisible(true);
            setVisible(false);
        } else if (command.equals("showNotifications")) {
            ReceptionistNotifications receptionistNotifications = new ReceptionistNotifications();
            receptionistNotifications.setVisible(true);
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        ReceptionistDashboard receptionistDashboard = new ReceptionistDashboard();
        receptionistDashboard.setVisible(true);
    }
}
