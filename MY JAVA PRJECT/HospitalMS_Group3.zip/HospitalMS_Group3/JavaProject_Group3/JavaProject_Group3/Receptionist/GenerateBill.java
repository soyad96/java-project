package Receptionist;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class GenerateBill extends JFrame implements ActionListener {
    private JTextField appointmentFeeField, medicineCostField, medicalTestFeeField, otherFeesField;
    private JButton calculateButton, backButton;

    public GenerateBill() {
        setTitle("Generate Bill");
        setSize(750, 550);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.decode("#99BC85")); 

        setLayout(null);

        JLabel appointmentLabel = new JLabel("Appointment Fee:");
        appointmentLabel.setBounds(50, 50, 150, 20); 
        appointmentLabel.setFont(new Font("Arial", Font.BOLD, 16)); 
        add(appointmentLabel);

        JLabel medicineLabel = new JLabel("Medicine Cost:");
        medicineLabel.setBounds(50, 80, 150, 20); 
        medicineLabel.setFont(new Font("Arial", Font.BOLD, 16)); 
        add(medicineLabel);

        JLabel medicalTestLabel = new JLabel("Medical Test Fee:");
        medicalTestLabel.setBounds(50, 110, 150, 20); 
        medicalTestLabel.setFont(new Font("Arial", Font.BOLD, 16)); 
        add(medicalTestLabel);

        JLabel otherFeesLabel = new JLabel("Other Fees:");
        otherFeesLabel.setBounds(50, 140, 150, 20); 
        otherFeesLabel.setFont(new Font("Arial", Font.BOLD, 16)); 
        add(otherFeesLabel);

        
        appointmentFeeField = new JTextField();
        appointmentFeeField.setBounds(400, 50, 180, 30); 
        appointmentFeeField.setHorizontalAlignment(SwingConstants.CENTER);
        add(appointmentFeeField);

        medicineCostField = new JTextField();
        medicineCostField.setBounds(400, 80, 180, 30); 
        medicineCostField.setHorizontalAlignment(SwingConstants.CENTER);
        add(medicineCostField);

        medicalTestFeeField = new JTextField();
        medicalTestFeeField.setBounds(400, 110, 180, 30); 
        medicalTestFeeField.setHorizontalAlignment(SwingConstants.CENTER);
        add(medicalTestFeeField);

        otherFeesField = new JTextField();
        otherFeesField.setBounds(400, 140, 180, 30); 
        otherFeesField.setHorizontalAlignment(SwingConstants.CENTER);
        add(otherFeesField);

        calculateButton = new JButton("Calculate Total");
        calculateButton.setBounds(400, 180, 200, 30); 
        calculateButton.setBackground(Color.decode("#092635"));
        calculateButton.setForeground(Color.WHITE);
        calculateButton.setFont(new Font("Arial", Font.BOLD, 16));
        calculateButton.addActionListener(this);
        add(calculateButton);

        backButton = new JButton("Back");
        backButton.setBounds(50, 180, 200, 30);
        backButton.setBackground(Color.decode("#092635"));
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ReceptionistDashboard receptionistDashboard = new ReceptionistDashboard();
                receptionistDashboard.setVisible(true);
                setVisible(false);

            }
        });
        add(backButton);

        setResizable(false); 
    }

    public void actionPerformed(ActionEvent e) {
    
        double appointmentFee = Double.parseDouble(appointmentFeeField.getText());
        double medicineCost = Double.parseDouble(medicineCostField.getText());
        double medicalTestFee = Double.parseDouble(medicalTestFeeField.getText());
        double otherFees = Double.parseDouble(otherFeesField.getText());
        double totalBill = appointmentFee + medicineCost + medicalTestFee + otherFees;

        try {
            FileWriter writer = new FileWriter("total_bill.txt");
            writer.write(String.valueOf(totalBill));
            writer.close();
            JOptionPane.showMessageDialog(this, "Total bill: $" + totalBill, "Total Bill", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error occurred while writing to file.");
        }
    }

    public static void main(String[] args) {
        GenerateBill billGenerator = new GenerateBill();
        billGenerator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        billGenerator.setVisible(true);
    }
}