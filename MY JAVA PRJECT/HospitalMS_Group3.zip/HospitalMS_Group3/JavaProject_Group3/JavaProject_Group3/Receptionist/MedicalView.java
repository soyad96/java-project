package Receptionist;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
 
public class MedicalView extends JFrame {
 
    public MedicalView() {
        setTitle("Medical Record View");
        setSize(750, 550);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.decode("#7AB2B2"));
        setLayout(new BorderLayout());
 
        JLabel welcomeLabel = new JLabel("Medical Record View", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.decode("#114232"));
        add(welcomeLabel, BorderLayout.NORTH);
 
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setBackground(Color.WHITE);
        textArea.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);
 
    
        try (BufferedReader reader = new BufferedReader(new FileReader("medical_record.txt"))) {
            textArea.read(reader, null);
        } catch (IOException e) {
            textArea.setText("Error reading medical record file.");
        }
 
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.decode("#7AB2B2"));
        JButton backButton = new JButton("Back");
        backButton.setBackground(Color.decode("#114232"));
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ReceptionistDashboard receptionistDashboard = new ReceptionistDashboard();
                receptionistDashboard.setVisible(true);
                setVisible(false);
               
            }
        });
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }
 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MedicalView().setVisible(true);
            }
        });
    }
}