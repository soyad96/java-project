package Patient;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class PatientDashboard extends JFrame implements ActionListener {
    private double totalBill; 

    public PatientDashboard() {
        setTitle("Patient Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        initComponents(); 
        setVisible(true);
    }

    private void initComponents() {
        
        ImageIcon backgroundImage = new ImageIcon(getClass().getResource("/images/new1.jpg"));
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setLayout(new BorderLayout());
        setContentPane(backgroundLabel);

        
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(5, 0, 10, 0);


        JLabel titleLabel = new JLabel("Your Premier Destination for Trusted Medical Services");
        titleLabel.setForeground(new Color(0, 0, 128));
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        centerPanel.add(titleLabel, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(10, 0, 20, 0);


        JLabel subtitleLabel = new JLabel("Where Commitment to Quality Meets Unparalleled Expertise, Setting the Standard for Reliable Healthcare.");
        subtitleLabel.setForeground(new Color(0, 0, 128));
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        centerPanel.add(subtitleLabel, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(20, 0, 0, 0);

        JPanel buttonsPanel = new JPanel(new GridLayout(3, 1));
        buttonsPanel.setOpaque(false);

        JButton appointButton = new JButton("Book an Appointment");
        appointButton.setBackground(Color.BLUE.darker());
        appointButton.setForeground(Color.WHITE);
        appointButton.setFont(new Font("Arial", Font.BOLD, 18));
        appointButton.addActionListener(this);
        appointButton.setActionCommand("bookAppointment");
        buttonsPanel.add(appointButton);

        JButton prescriptionButton = new JButton("View Your Prescription");
        prescriptionButton.setBackground(Color.BLUE.darker());
        prescriptionButton.setForeground(Color.WHITE);
        prescriptionButton.setFont(new Font("Arial", Font.BOLD, 18));
        prescriptionButton.addActionListener(this);
        prescriptionButton.setActionCommand("viewPrescription");
        buttonsPanel.add(prescriptionButton);

        JButton payBillButton = new JButton("Pay Your Bill");
        payBillButton.setBackground(Color.BLUE.darker());
        payBillButton.setForeground(Color.WHITE);
        payBillButton.setFont(new Font("Arial", Font.BOLD, 18));
        payBillButton.addActionListener(this);
        payBillButton.setActionCommand("payBill");
        buttonsPanel.add(payBillButton);

        centerPanel.add(buttonsPanel, gbc);

        backgroundLabel.add(centerPanel, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        switch (command) {
            case "bookAppointment":
                dispose();
                new AppointmentForm();
                break;
            case "viewPrescription":
                dispose();
                new PrescriptionViewer(this);
                setVisible(false);
                break;
            case "payBill":
                try {
                    readTotalBill();
                    new PayBill(totalBill);
                    dispose();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                break;
        }
    }

    private void readTotalBill() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("total_bill.txt"));
        String totalBillStr = reader.readLine();
        totalBill = Double.parseDouble(totalBillStr);
        reader.close();
    }

    public static void main(String[] args) {
        new PatientDashboard();
    }
}
