package Patient;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class PrescriptionViewer extends JFrame {

    public PrescriptionViewer(JFrame parent) {
        setTitle("View Prescription");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel background = new JLabel(new ImageIcon("images/new3.jpg"));
        setContentPane(background);
        setLayout(new FlowLayout());

        JTextArea prescriptionArea = new JTextArea(20, 50);
        prescriptionArea.setFont(new Font("Serif", Font.PLAIN, 16));
        prescriptionArea.setLineWrap(true);
        prescriptionArea.setWrapStyleWord(true);
        prescriptionArea.setEditable(false);

        try (BufferedReader br = new BufferedReader(new FileReader("prescription.txt"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
            prescriptionArea.setText(sb.toString());
        } catch (IOException e) {
            prescriptionArea.setText("Error: Unable to load prescription.");
        }

        JScrollPane scrollPane = new JScrollPane(prescriptionArea);
        scrollPane.setPreferredSize(new Dimension(750, 500));

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 12));
        backButton.setBackground(Color.BLUE);
        backButton.setForeground(Color.WHITE);
        backButton.setOpaque(true);
        backButton.setBorderPainted(false);

        
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parent.setVisible(true);
                dispose();
            }
        });

        add(backButton, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);
    }
}
