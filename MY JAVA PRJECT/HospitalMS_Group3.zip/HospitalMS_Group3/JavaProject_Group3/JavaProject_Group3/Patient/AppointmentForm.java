package Patient;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;

public class AppointmentForm extends JFrame implements ActionListener {
    private JTextField nameField;
    private JTextField ageField;
    private JTextField weightField;
    private JButton submitButton, backButton;
    private JRadioButton maleRadioButton;
    private JRadioButton femaleRadioButton;
    private ButtonGroup genderGroup;
    private JComboBox<String> dayComboBox;
    private JComboBox<String> monthComboBox;
    private JComboBox<String> yearComboBox;

    public AppointmentForm() {
        setTitle("Appointment Form");
        setSize(800, 600);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLayeredPane layeredPane = new JLayeredPane();
        setContentPane(layeredPane);

        ImageIcon backgroundImage = new ImageIcon("images/new2.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, backgroundImage.getIconWidth(), backgroundImage.getIconHeight());
        layeredPane.add(backgroundLabel, JLayeredPane.DEFAULT_LAYER);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(9, 2));
        formPanel.setOpaque(false);
        formPanel.setBounds(50, 50, 700, 500);
        layeredPane.add(formPanel, JLayeredPane.PALETTE_LAYER);

        JLabel instructionsLabel = new JLabel("Provide Your Details to Get an Appointment");
        instructionsLabel.setHorizontalAlignment(JLabel.CENTER);
        instructionsLabel.setForeground(new Color(0, 0, 139));
        instructionsLabel.setFont(new Font("Calibri", Font.BOLD, 18));
        formPanel.add(instructionsLabel);
        formPanel.add(new JLabel());

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        formPanel.add(nameLabel);
        nameField = new JTextField();
        nameField.setPreferredSize(new Dimension(150, 30));
        nameField.setFont(new Font("Arial", Font.BOLD, 18));
        formPanel.add(nameField);

        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setFont(new Font("Arial", Font.BOLD, 18));
        formPanel.add(ageLabel);
        ageField = new JTextField();
        ageField.setPreferredSize(new Dimension(50, 30));
        ageField.setFont(new Font("Arial", Font.BOLD, 18));
        formPanel.add(ageField);

        JLabel weightLabel = new JLabel("Weight:");
        weightLabel.setFont(new Font("Arial", Font.BOLD, 18));
        formPanel.add(weightLabel);
        weightField = new JTextField();
        weightField.setPreferredSize(new Dimension(50, 30));
        weightField.setFont(new Font("Arial", Font.BOLD, 18));
        formPanel.add(weightField);
        
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setFont(new Font("Arial", Font.BOLD, 18));
        formPanel.add(genderLabel);
        JPanel genderPanel = new JPanel();
        genderPanel.setOpaque(false);
        maleRadioButton = new JRadioButton("Male");
        femaleRadioButton = new JRadioButton("Female");
        maleRadioButton.setFont(new Font("Arial", Font.PLAIN, 18));
        femaleRadioButton.setFont(new Font("Arial", Font.PLAIN, 18));
        genderGroup = new ButtonGroup();
        genderGroup.add(maleRadioButton);
        genderGroup.add(femaleRadioButton);
        genderPanel.add(maleRadioButton);
        genderPanel.add(femaleRadioButton);
        formPanel.add(genderPanel);

        
        JLabel appointmentDateLabel = new JLabel("Appointment Date:");
        appointmentDateLabel.setFont(new Font("Arial", Font.BOLD, 18));
        formPanel.add(appointmentDateLabel);

        JPanel sadPanel = new JPanel();
        sadPanel.setOpaque(false);
        dayComboBox = new JComboBox<>(getDays());
        dayComboBox.setFont(new Font("Arial", Font.PLAIN, 18));
        monthComboBox = new JComboBox<>(getMonths());
        monthComboBox.setFont(new Font("Arial", Font.PLAIN, 18));
        yearComboBox = new JComboBox<>(getYears());
        yearComboBox.setFont(new Font("Arial", Font.PLAIN, 18));
        sadPanel.add(dayComboBox);
        sadPanel.add(monthComboBox);
        sadPanel.add(yearComboBox);
        formPanel.add(sadPanel);

        
        submitButton = new JButton("Submit");
        submitButton.setPreferredSize(new Dimension(120, 40));
        submitButton.setBackground(new Color(0, 0, 139));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFont(new Font("Arial", Font.BOLD, 18));
        submitButton.addActionListener(this);
        formPanel.add(submitButton);

        formPanel.add(new JLabel());
        formPanel.add(new JLabel());

        backButton = new JButton("Back");
        backButton.setBackground(new Color(0, 0, 139));
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Arial", Font.BOLD, 18));
        backButton.addActionListener(this);
        layeredPane.add(backButton, JLayeredPane.PALETTE_LAYER);
        backButton.setBounds(10, 10, 100, 40);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            if (fieldsAreFilled()) {
                submitForm();
            } else {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            }
        } else if (e.getSource() == backButton) {
            PatientDashboard patientDashboard = new PatientDashboard();
            patientDashboard.setVisible(true);
            setVisible(false);
        }
    }

    private boolean fieldsAreFilled() {
        return !nameField.getText().isEmpty() &&
                !ageField.getText().isEmpty() &&
                !weightField.getText().isEmpty() &&
                (maleRadioButton.isSelected() || femaleRadioButton.isSelected());
    }

    private void submitForm() {
        String name = nameField.getText();
        String age = ageField.getText();
        String weight = weightField.getText();
        String gender = maleRadioButton.isSelected() ? "Male" : "Female";
        String appointmentDate = dayComboBox.getSelectedItem() + "-" + monthComboBox.getSelectedItem() + "-" + yearComboBox.getSelectedItem();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("appointment_info.txt", true))) {
            writer.write("Name: " + name + ", Age: " + age + ", Weight: " + weight + ", Gender: " + gender + ", Appointment Date: " + appointmentDate + "\n");
            writer.flush();
            JOptionPane.showMessageDialog(this, "Information submitted successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error occurred while saving information.");
        }
    }

    private String[] getDays() {
        String[] days = new String[31];
        for (int i = 0; i < 31; i++) {
            days[i] = String.valueOf(i + 1);
        }
        return days;
    }

    private String[] getMonths() {
        return new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    }

    private String[] getYears() {
        String[] years = new String[20];
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = 0; i < 20; i++) {
            years[i] = String.valueOf(currentYear - i);
        }
        return years;
    }

    public static void main(String[] args) {
        new AppointmentForm();
    }
}
