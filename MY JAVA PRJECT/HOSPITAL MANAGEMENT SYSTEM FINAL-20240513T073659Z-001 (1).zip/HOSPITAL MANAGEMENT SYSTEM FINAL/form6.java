// BMI CALCULATE PAGE

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class form6 extends JFrame implements ActionListener 
{
    JPanel panel;
    JLabel label, label2;
    JButton backbtn, calculatebtn;
    JTextField heightfld, weightfld;
    ImageIcon img1, img2, img3;

    form6() 
    {
        super("Calculate Body Mass Index (BMI)");
        this.setSize(905, 485);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        img1 = new ImageIcon("checkBMIbackground.png");
        label = new JLabel(img1);
        label.setBounds(0, 0, 900, 480);
        panel.add(label);

        label2=new JLabel();
        label2.setBounds(315,342,370,30);
        label2.setFont(new Font("Arial",Font.BOLD,32));
        label2.setForeground(Color.BLACK);
        label.add(label2);

        img2 = new ImageIcon("backbtn.png");
        backbtn = new JButton(img2);
        backbtn.setBounds(690, 400, 102, 32);
        backbtn.addActionListener(this);
        label.add(backbtn);

        img3 = new ImageIcon("calculatebtn.png");
        calculatebtn = new JButton(img3);
        calculatebtn.setBounds(450, 255, 96, 30);
        calculatebtn.addActionListener(this);
        label.add(calculatebtn);

        heightfld = new JTextField();
        heightfld.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
        heightfld.setBounds(330, 261, 80, 20);
        heightfld.setOpaque(false);
        heightfld.setBorder(BorderFactory.createEmptyBorder());
        heightfld.setForeground(Color.WHITE);
        label.add(heightfld);

        weightfld = new JTextField();
        weightfld.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
        weightfld.setBounds(330, 202, 80, 20);
        weightfld.setOpaque(false);
        weightfld.setBorder(BorderFactory.createEmptyBorder());
        weightfld.setForeground(Color.WHITE);
        label.add(weightfld);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae) 
    {
        String H = heightfld.getText();
        String W = weightfld.getText();
        float Height = Float.parseFloat(H);
        float Weight = Float.parseFloat(W);

        if(ae.getSource()==calculatebtn)
        {
            if(H.isEmpty()||W.isEmpty())
            {
                JOptionPane.showMessageDialog(this,"Enter Details First");
            }
            else
            {
                float H1 = Height * 0.0254F;
                float H2 = H1 * H1;
                float result = Weight / H2;

                if (result < 18.5) 
                {
                    label2.setForeground(Color.ORANGE);
                }          
                else if (result < 25) 
                {
                    label2.setForeground(Color.GREEN);
                } 
                else if (result < 35) 
                {
                    label2.setForeground(Color.ORANGE);
                } 
                else 
                {
                    label2.setForeground(Color.RED);
                }

                label2.setText(String.format("%.2f", result));
            } 
        }
        else if(ae.getSource() == backbtn) 
        {
            form4 f1 = new form4();
            f1.setVisible(true);
            this.setVisible(false);
        }
    }
}
