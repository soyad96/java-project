// Doctor 2

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class doctor2 extends JFrame
{
	JPanel panel;
	JLabel label;
	ImageIcon img1;
	
	
	doctor2()
	{
		super("Doctor-2 Details");	
		this.setSize(650, 400);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		img1= new ImageIcon("d2.png");
		
		label = new JLabel(img1);
		label.setBounds(0, 0, 650, 400);
		panel.add(label);
		
		this.add(panel);
		
	}


}
