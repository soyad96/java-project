// EMERGENCY CONTACT

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class form5 extends JFrame implements ActionListener
{
	JPanel panel;
	JLabel label;
	JButton button;
	ImageIcon img1,img2;
	
	
	form5()
	{
		super("Emergency Contact");	
		this.setSize(905, 485);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
        

		panel = new JPanel();
		panel.setLayout(null);


		img1 = new ImageIcon("emergency.png");
		label = new JLabel(img1);
		label.setBounds(0, 0, 900, 480);
		panel.add(label);

        img2 = new ImageIcon("backbtn.png");
		button = new JButton(img2);
		button.setBounds(690,400,102,32);
		button.addActionListener(this);
		label.add(button);
		

		
		this.add(panel);
		
	}


	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==button)
			{
			    form4 f = new form4();
				this.setVisible(false);
				f.setVisible(true);
			}

		}


}
