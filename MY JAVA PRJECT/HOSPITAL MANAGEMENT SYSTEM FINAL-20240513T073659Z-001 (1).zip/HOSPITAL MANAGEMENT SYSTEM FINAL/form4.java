// HOME PAGE

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class form4 extends JFrame implements ActionListener
{
	JPanel panel;
	JLabel label;
	JButton bookbtn, infobtn, contactbtn, bmibtn, backbtn;
    ImageIcon img1,img2,img3,img4,img5,img6;

	public form4()
	{
		super("Diagnose Your Health Homepage");	
		this.setSize(1010,580);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		img1 = new ImageIcon("homepage.png");
		label = new JLabel(img1);
		label.setBounds(0,0,1000,550);
		panel.add(label);

		img2 = new ImageIcon("bookappointbtn.png");
		bookbtn = new JButton(img2);
		bookbtn.setBounds(195,168,270,123);
		label.add(bookbtn);
		
		img3 = new ImageIcon("viewdoctorsinfobtn.png");
		infobtn = new JButton(img3);
		infobtn.setBounds(540,168,270,123);
		infobtn.addActionListener(this);
		label.add(infobtn);

		img4 = new ImageIcon("checkBMI.png");
		bmibtn = new JButton(img4);
		bmibtn.setBounds(195,305,270,123);
		bmibtn.addActionListener(this);
		label.add(bmibtn);

		img5 = new ImageIcon("emergencycontactbtn.png");
		contactbtn = new JButton(img5);
		contactbtn.setBounds(540,305,270,123);
		contactbtn.addActionListener(this);
		label.add(contactbtn);

		img6 = new ImageIcon("backbtn.png");
		backbtn = new JButton(img6);
		backbtn.setBounds(145,455,102,32);
		backbtn.addActionListener(this);
		label.add(backbtn);


		this.add(panel);
		
	}
	

public void actionPerformed(ActionEvent ae)
		{
		    if(ae.getSource()==backbtn)
			{
				form2 f = new form2();
				this.setVisible(false);
				f.setVisible(true);
			}

			else if(ae.getSource()==contactbtn)
			{
				form5 f= new form5();
				f.setVisible(true);
				this.setVisible(false);
			}
			else if(ae.getSource()==bmibtn)
			{
				form6 f= new form6();
				f.setVisible(true);
				this.setVisible(false);
			}
			else if(ae.getSource()==infobtn)
			{
				form7 f7= new form7();
				f7.setVisible(true);
				this.setVisible(false);
			}

		}


}

