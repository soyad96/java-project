// VIEW DOCTORS INFO

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class form7 extends JFrame implements ActionListener
{
	JPanel panel;
	JLabel label;
	JButton backbtn,d1,d2,d3,d4,d5,d6;
	ImageIcon img1,img2,img3;
	
	
	form7()
	{
		super("Doctors Info");	
		this.setSize(1010, 560);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
        

		panel = new JPanel();
		panel.setLayout(null);


		img1 = new ImageIcon("doctorsinfo.png");
		label = new JLabel(img1);
		label.setBounds(0, 0, 1000, 550);
		panel.add(label);

        img2 = new ImageIcon("backbtn.png");
		backbtn = new JButton(img2);
		backbtn.setBounds(130,485,102,32);
		backbtn.addActionListener(this);
		label.add(backbtn);

		img3 = new ImageIcon("details.png");
		d1 = new JButton(img3);
		d1.setBounds(800,192,96,26);
		d1.addActionListener(this);
		label.add(d1);
		
		d2 = new JButton(img3);
		d2.setBounds(800,239,96,26);
		d2.addActionListener(this);
		label.add(d2);

		d3 = new JButton(img3);
		d3.setBounds(800,284,96,26);
		d3.addActionListener(this);
		label.add(d3);

		d4 = new JButton(img3);
		d4.setBounds(800,331,96,26);
		d4.addActionListener(this);
		label.add(d4);

		d5 = new JButton(img3);
		d5.setBounds(800,381,96,26);
		d5.addActionListener(this);
		label.add(d5);

		d6 = new JButton(img3);
		d6.setBounds(800,428,96,26);
		d6.addActionListener(this);
		label.add(d6);

		
		this.add(panel);
		
	}


	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==backbtn)
			{
			    form4 f6 = new form4();
				this.setVisible(false);
				f6.setVisible(true);
			}
			else if(ae.getSource()==d1)
			{
				doctor1 d1= new doctor1();
				d1.setVisible(true);
			}
			else if(ae.getSource()==d2)
			{
				doctor2 d1= new doctor2();
				d1.setVisible(true);
			}
			else if(ae.getSource()==d3)
			{
				doctor3 d1= new doctor3();
				d1.setVisible(true);
			}
			else if(ae.getSource()==d4)
			{
				doctor4 d1= new doctor4();
				d1.setVisible(true);
			}
			else if(ae.getSource()==d5)
			{
				doctor5 d1= new doctor5();
				d1.setVisible(true);
			}
			else if(ae.getSource()==d6)
			{
				doctor6 d1= new doctor6();
				d1.setVisible(true);
			}






		}

		public static void main(String args[])
		{
			form7 f= new form7();
			f.setVisible(true);
		}


}
