// LOG IN 

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class form2 extends JFrame implements ActionListener
{
    JPanel panel;
	JLabel label;
	JTextField emailfld;
	JPasswordField passfld;
	JButton backbtn, loginbtn, signupbtn;

	ImageIcon img1,img3,img4, img5;
	
	form2()
	{
		super("Login or Sign Up");	
		this.setSize(1000,580);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		img1 = new ImageIcon("loginPage.png");
		
		label = new JLabel(img1);
		label.setBounds(0, 0, 1000, 550);
		panel.add(label);
		
	
		emailfld = new JTextField();
        emailfld.setFont(new  Font("Comic Sans MS",Font.PLAIN,20));
        emailfld.setBounds(375,218,231,24);
        emailfld.setOpaque(false);
        emailfld.setForeground(Color.WHITE);
        emailfld.setBorder(BorderFactory.createEmptyBorder());
        label.add(emailfld);

        passfld = new JPasswordField();
        passfld.setFont(new  Font("Comic Sans MS",Font.PLAIN,20));
        passfld.setBounds(375,291,231,24);
        passfld.setEchoChar('*');
        passfld.setForeground(Color.WHITE);
        passfld.setOpaque(false);
        passfld.setBorder(BorderFactory.createEmptyBorder());
        label.add(passfld);
		
		
		
		img3 = new ImageIcon("loginbtn.png");
		loginbtn = new JButton(img3);
		loginbtn.setBounds(450,430,102,32);
		loginbtn.addActionListener(this);
		label.add(loginbtn);

        img4 = new ImageIcon("backbtn.png");
		backbtn = new JButton(img4);
		backbtn.setBounds(270,430,102,32);
		backbtn.addActionListener(this);
		label.add(backbtn);

		img4 = new ImageIcon("signupbtn.png");
		signupbtn = new JButton(img4);
		signupbtn.setBounds(620,430,102,32);
		signupbtn.addActionListener(this);
		label.add(signupbtn);
		
		this.add(panel);
	}	

	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		String email=emailfld.getText();
		String pass=passfld.getText();
		
		Account acc=new Account();
		
		if(ae.getSource()==signupbtn)
		{
		
			form3 f=new form3();
			f.setVisible(true);
			this.setVisible(false);
		}

		else if(ae.getSource()==backbtn)
		{
			form f= new form();
			f.setVisible(true);
			this.setVisible(false);
		}

		else if(ae.getSource()==signupbtn)
		{
			form3 f=new form3();
			f.setVisible(true);
			this.setVisible(false);
		}
		else if(loginbtn.getText().equals(command))
		{
			if(email.isEmpty()||pass.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill Up All First");
			}
			
			else if(acc.checkAccount(email,pass)==true)
			{
				
			JOptionPane.showMessageDialog(this,"Login Successful");
			
			form4 f=new form4();
			f.setVisible(true);
			this.setVisible(false);
			}
			else
			{
				JOptionPane.showMessageDialog(this,"Incorrect Email or Password");
			}
		}
		


}

}

	