// SIGN UP 

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class form3 extends JFrame implements ActionListener
{
	JPanel panel,i;
	JLabel label;
	JButton backbtn, registerbtn;
    JTextField namefld,emailfld,mobilefld,addressfld;
    JPasswordField passfld;
	ImageIcon img1,img2,img3,img4,img5;
	
	form3()
	{
		super("Register Your Info");	
		this.setSize(1010,580);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
	
		
		img2 = new ImageIcon("signuppage.png");
		label = new JLabel(img2);
		label.setBounds(0,0,1000,550);
		panel.add(label);

		
		namefld = new JTextField();
        namefld.setFont(new  Font("Comic Sans MS",Font.BOLD,18));
		namefld.setBounds(355,163,280,29);
	
		label.add(namefld);

        emailfld = new JTextField();
        emailfld.setFont(new  Font("Comic Sans MS",Font.BOLD,18));
        emailfld.setBounds(355,217,280,29);
     
        label.add(emailfld);
        

        addressfld = new JTextField();
        addressfld.setFont(new  Font("Comic Sans MS",Font.BOLD,18));
		addressfld.setBounds(355,275,280,29);
	
        label.add(addressfld);
        
        mobilefld = new JTextField();
        mobilefld.setFont(new  Font("Comic Sans MS",Font.BOLD,18));
		mobilefld.setBounds(355,334,280,29);
	
        label.add(mobilefld);
        
        passfld = new JPasswordField();
        passfld.setFont(new  Font("Comic Sans MS",Font.BOLD,18));
		passfld.setBounds(355,389,280,29);
		passfld.setEchoChar('*');

        label.add(passfld);
        
 
		img3 = new ImageIcon("backbtn.png");
		backbtn = new JButton(img3);
		backbtn.setBounds(200,455,102,32);
		backbtn.addActionListener(this);
		label.add(backbtn);
		
		img4 = new ImageIcon("registerbtn.png");
		registerbtn = new JButton(img4);
		registerbtn.setBounds(560,455,102,32);
        registerbtn.addActionListener(this);
		label.add(registerbtn);
		
		
		this.add(panel);
		
	}

	public void actionPerformed(ActionEvent ae)
	{
		String s1=emailfld.getText();
		String s2=passfld.getText();
		
		if(ae.getSource()==registerbtn)
		{
			if(s1.isEmpty()||s2.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill Up All First");
			}
			else{
				
				Account acc=new Account(s1,s2);
				acc.addAccount();
				
			JOptionPane.showMessageDialog(this,"Registration Successful");
			form2 f=new form2();
			f.setVisible(true);
			this.setVisible(false);
			}
		}
		else if(ae.getSource()==backbtn)
		{
			form2 f=new form2();
			f.setVisible(true);
			this.setVisible(false);
		}
	}
	

	
}
