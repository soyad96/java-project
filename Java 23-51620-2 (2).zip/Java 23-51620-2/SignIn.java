import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignIn extends JFrame implements ActionListener, MouseListener {
    private Container c;
    private JLabel usernameLabel, passwordLabel, signUpLabel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton signInButton;
    
    public SignIn() {
        super("Sign In");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        c = getContentPane();
        c.setLayout(null);
        c.setBackground(Color.decode("#81D4FA"));

        usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(250, 50, 100, 30);
        c.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(360, 50, 150, 30);
        c.add(usernameField);

        passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(250, 100, 100, 30);
        c.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(360, 100, 150, 30);
        c.add(passwordField);

        signInButton = new JButton("Sign In");
        signInButton.setBounds(360, 150, 100, 30);
        signInButton.addActionListener(this);
        c.add(signInButton);

        signUpLabel = new JLabel("Don't have an account? SignUp");
        signUpLabel.setBounds(300, 200, 200, 30);
        signUpLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signUpLabel.addMouseListener(this);
        c.add(signUpLabel);

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signInButton) {
            String name = usernameField.getText();
            String password =  new String(passwordField.getPassword());

            // Authenticating the user based on the role
            Account acc = new Account();
            boolean isValid = acc.validAccount(name, password);

            if (isValid) {
                String role = acc.getRole(name); // Retrieve role based on username
                JOptionPane.showMessageDialog(this, "Login Successful");

                // Open different windows based on the role
                switch (role) {
                    case "Doctor":
                        DoctorDashboard doctorDashboard = new DoctorDashboard();
                        doctorDashboard.setVisible(true);
                        break;
                    case "Patient":
                        PatientDashboard patientDashboard = new PatientDashboard();
                        patientDashboard.setVisible(true);
                        break;
                    case "Receptionist":
                        ReceptionistDashboard receptionistDashboard = new ReceptionistDashboard();
                        receptionistDashboard.setVisible(true);
                        break;
                    case "Admin":
                        AdminDashboard adminDashboard = new AdminDashboard();
                        adminDashboard.setVisible(true);
                        break;
                    default:
                        JOptionPane.showMessageDialog(this, "Invalid role.");
                        break;
                }

                this.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(this, "Login Failed");
            }
        }
    }

    public void mouseClicked(MouseEvent me) {
        if (me.getSource() == signUpLabel) {
            SignUp signup = new SignUp();
            signup.setVisible(true);
            this.setVisible(false);
        }
    }

    public void mousePressed(MouseEvent me) {}
    public void mouseReleased(MouseEvent me) {}
    public void mouseEntered(MouseEvent me) {}
    public void mouseExited(MouseEvent me) {}
}
