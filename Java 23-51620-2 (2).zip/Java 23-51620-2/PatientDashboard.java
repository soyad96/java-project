import javax.swing.*;
import java.awt.*;

public class PatientDashboard extends JFrame {
    public PatientDashboard() {
        setTitle("Patient Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        // Background image
        ImageIcon backgroundImage = new ImageIcon(getClass().getResource("/images/new1.jpg"));
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setLayout(new BorderLayout());
        setContentPane(backgroundLabel);
        
        // Center panel with text and buttons
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(5, 0, 10, 0); // Add vertical spacing with smaller gap between title and subtitle
        
        // Title
        JLabel titleLabel = new JLabel("Your Premier Destination for Trusted Medical Services");
        titleLabel.setForeground(new Color(0, 0, 128)); // Navy blue
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center the text
        centerPanel.add(titleLabel, gbc);
        
        gbc.gridy++;
        gbc.insets = new Insets(10, 0, 20, 0); // Add a larger gap between subtitle and buttons
        
        // Subtitle
        JLabel subtitleLabel = new JLabel("Where Commitment to Quality Meets Unparalleled Expertise, Setting the Standard for Reliable Healthcare.");
        subtitleLabel.setForeground(new Color(0, 0, 128)); // Navy blue
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center the text
        centerPanel.add(subtitleLabel, gbc);
        
        gbc.gridy++;
        gbc.insets = new Insets(20, 0, 0, 0); // Add top margin for buttons
        
        // Buttons panel
        JPanel buttonsPanel = new JPanel(new GridLayout(2, 1)); // Two buttons in a grid
        buttonsPanel.setOpaque(false);
        
        JButton infoButton = new JButton("Provide Your Information");
        infoButton.setBackground(Color.BLUE.darker()); // Darker shade of blue
        infoButton.setForeground(Color.WHITE);
        infoButton.setFont(new Font("Arial", Font.BOLD, 18));
        buttonsPanel.add(infoButton);
        
        JButton appointmentButton = new JButton("Schedule Appointment");
        appointmentButton.setBackground(Color.BLUE.darker()); // Darker shade of blue
        appointmentButton.setForeground(Color.WHITE);
        appointmentButton.setFont(new Font("Arial", Font.BOLD, 18));
        buttonsPanel.add(appointmentButton);
        
        // Add buttons panel to center panel
        centerPanel.add(buttonsPanel, gbc);
        
        // Add center panel to content pane
        backgroundLabel.add(centerPanel, BorderLayout.CENTER);
        
        setVisible(true);
    }


    public static void main(String[] args) {
        PatientDashboard patientDashboard = new PatientDashboard();
    }
}
