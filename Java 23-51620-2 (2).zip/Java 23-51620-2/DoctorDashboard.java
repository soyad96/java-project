import javax.swing.JFrame;
import java.awt.*;

public class DoctorDashboard extends JFrame {
    

    private Container c; 

    public DoctorDashboard() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("doctor Dashboard");
        this.setSize(1400, 800);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
    }

    public static void main(String[] args) {
        DoctorDashboard doctorDashboard = new DoctorDashboard();
        doctorDashboard.setVisible(true);
    }
}
