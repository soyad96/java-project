import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignUp extends JFrame implements ActionListener {

    private Container c;
    private JLabel usernameLabel, passwordLabel, roleLabel, image;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton signUpButton;
    private JComboBox<String> roleComboBox;
    private ImageIcon imageIcon;

    public SignUp() {
        super("Sign Up");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.decode("#81D4FA"));

        imageIcon = new ImageIcon(getClass().getResource("/images/hospital-png-4.png"));
        image = new JLabel(imageIcon);
        image.setBounds(365, 70, 130, 130);
        c.add(image);

        usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(250, 220, 100, 30);
        c.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(360, 220, 150, 30);
        c.add(usernameField);

        passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(250, 270, 100, 30);
        c.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(360, 270, 150, 30);
        c.add(passwordField);

        roleLabel = new JLabel("Role:");
        roleLabel.setBounds(250, 320, 100, 30);
        c.add(roleLabel);

        
        String[] roles = {"Doctor", "Patient", "Receptionist", "Admin"};
        roleComboBox = new JComboBox<>(roles);
        roleComboBox.setBounds(360, 320, 150, 30);
        c.add(roleComboBox);

        signUpButton = new JButton("Sign Up");
        signUpButton.setBounds(390, 370, 100, 30);
        signUpButton.addActionListener(this);
        c.add(signUpButton);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signUpButton) {
            String s1, s2, role;
            s1 = usernameField.getText();
            s2 = passwordField.getText();
            role = (String) roleComboBox.getSelectedItem();

            if (s1.equals("") || s2.equals("")) {
                JOptionPane.showMessageDialog(null, "Please fill in all the fields!");
            } else {
                Account acc = new Account(s1, s2, role);
                if (acc.checkAccount(s1)) {
                    JOptionPane.showMessageDialog(this, "Username already exists");
                } else {
                    acc.addAccount();
                    JOptionPane.showMessageDialog(this, "Registration Successful");
                    SignIn signIn = new SignIn();
                    signIn.setVisible(true);
                    this.setVisible(false);
                }
            }
        }
    }

    public static void main(String[] args) {
        SignUp signUp = new SignUp();
        signUp.setVisible(true);
    }
}

