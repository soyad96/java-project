import javax.swing.JFrame;
import java.awt.*;

public class AdminDashboard extends JFrame {
    

    private Container c; 

    public AdminDashboard() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("AdminDashboard");
        this.setSize(1400, 800);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
    }

    public static void main(String[] args) {
        AdminDashboard adminDashboard = new AdminDashboard();
        adminDashboard.setVisible(true);
    }
}
