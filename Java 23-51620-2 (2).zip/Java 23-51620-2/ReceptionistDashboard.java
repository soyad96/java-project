import javax.swing.JFrame;
import java.awt.*;

public class ReceptionistDashboard extends JFrame {
    

    private Container c; 

    public ReceptionistDashboard() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("receptionist dashboard");
        this.setSize(1400, 800);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
    }

    public static void main(String[] args) {
        ReceptionistDashboard receptionistDashboard = new ReceptionistDashboard();
        receptionistDashboard.setVisible(true);
    }
}
